from data.grid import sGrid, tGrid
from numerics.lax_wendroff import lax_wendroff
from numerics.bc import set_boundary
from data import io


if __name__ == '__main__':
    user_data, sol_init = io.get_args()
    ud = user_data()

    writer = io.writer()

    sg = sGrid(ud)
    tg = tGrid(ud)
    writer.write_attr(sg)
    writer.write_attr(tg)

    sol = sol_init(sg)

    for t in tg.t:
        lax_wendroff(sol, tg, sg, ud)
        set_boundary(sol)






